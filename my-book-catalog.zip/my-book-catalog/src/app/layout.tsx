import Providers from "./providers";
import "./globals.css";
import Navbar from "@/components/navbar";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full">
        <Providers>
          <main className="container mx-auto px-4">
            <Navbar />
            {children}
          </main>
        </Providers>
      </body>
    </html>
  );
}