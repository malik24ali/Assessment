"use client";
import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";
import Link from "next/link";

type Book = {
  id: string;
  title: string;
  author: string;
  genre: string;
  createdAt: string;
  user?: { name?: string; email?: string };
};

export default function Home() {
  const { data: session, status } = useSession();
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (status === "authenticated") {
      fetch("/api/books")
        .then((res) => res.json())
        .then((data) => {
          setBooks(data || []);
          setLoading(false);
        });
    }
  }, [status]);

  async function handleDelete(id: string) {
    if (!confirm("Delete this book?")) return;
    const res = await fetch(`/api/books?id=${id}`, { method: "DELETE" });
    if (res.ok) setBooks((b) => b.filter((x) => x.id !== id));
    else alert("Delete failed");
  }

  const filteredBooks = books.filter(
    (b) =>
      b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.author.toLowerCase().includes(search.toLowerCase()) ||
      b.genre.toLowerCase().includes(search.toLowerCase())
  );

  if (status === "loading")
    return <p className="p-8 text-center text-gray-500">Loading...</p>;
  if (!session)
    return (
      <p className="p-8 text-center text-gray-500">
        Please login to manage your books.
      </p>
    );

  return (
    <div className="min-h-screen bg-gray-100 px-4 sm:px-6 lg:px-8 py-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl sm:text-4xl font-bold text-center text-gray-800 mb-2">
          📚 My Book Catalog
        </h1>
        <p className="text-center text-gray-600 mb-6">
          View, add, or delete your books below.
        </p>

        {/* Add Book Button */}
        <div className="flex justify-center mb-6">
          <Link
            href="/add"
            className="px-6 py-2 bg-blue-600 text-white rounded-md shadow hover:bg-blue-700 transition"
          >
            Add New Book
          </Link>
        </div>

        {/* Search Bar */}
        <input
          type="text"
          placeholder="Search by title, author, or genre..."
          className="w-full p-3 mb-6 rounded-md border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm sm:text-base"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {/* Book List */}
        {loading ? (
          <p className="text-center text-gray-500">Loading books...</p>
        ) : filteredBooks.length === 0 ? (
          <p className="text-center text-gray-500">No books found.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBooks.map((b) => (
              <div
                key={b.id}
                className="flex flex-col justify-between bg-white p-5 rounded-xl shadow hover:shadow-lg transition"
              >
                <div>
                  <h3 className="text-lg sm:text-xl font-bold text-gray-800">
                    {b.title}
                  </h3>
                  <p className="text-gray-600">{b.author}</p>
                  <p className="text-gray-500 text-sm">{b.genre}</p>
                  <p className="text-gray-400 text-xs mt-1">
                    Added by: {b.user?.name ?? b.user?.email ?? "Unknown"}
                  </p>
                </div>
                <div className="flex justify-between items-center mt-4">
                  <p className="text-gray-400 text-xs">
                    {new Date(b.createdAt).toLocaleDateString()}
                  </p>
                  <button
                    onClick={() => handleDelete(b.id)}
                    className="px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600 transition"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
