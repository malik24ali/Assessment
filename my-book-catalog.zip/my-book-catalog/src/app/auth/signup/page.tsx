"use client";
import React from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function SignUpPage() {
  const { register, handleSubmit } = useForm<{ name?: string; email: string; password: string }>();
  const router = useRouter();

  async function onSubmit(data: any) {
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (res.ok) router.push("/auth/signin");
    else alert(json.error || "Error");
  }

  return (
    <main className="flex items-center justify-center min-h-screen bg-gray-100 px-4">
      <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-md space-y-6">
        <h1 className="text-2xl font-bold text-black text-center">Sign Up</h1>

        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col space-y-4">
          <input
            {...register("name")}
            placeholder="Name"
            className="w-full border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <input
            {...register("email", { required: true })}
            placeholder="Email"
            type="email"
            className="w-full border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <input
            {...register("password", { required: true, minLength: 6 })}
            placeholder="Password"
            type="password"
            className="w-full border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button
            type="submit"
            className="bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
          >
            Create Account
          </button>
        </form>

        <p className="text-center text-gray-600">
          Already have an account?{" "}
          <Link href="/auth/signin" className="text-blue-600 font-semibold hover:underline">
            Sign In
          </Link>
        </p>
      </div>
    </main>
  );
}
