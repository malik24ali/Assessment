"use client";
import { signIn } from "next-auth/react";
import Link from "next/link";

export default function SignIn() {
  return (
    <main className="flex items-center justify-center min-h-screen bg-gray-100 px-4">
      <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-md space-y-6">
        <h1 className="text-2xl font-bold text-black text-center">Sign In</h1>

        {/* Credentials Sign In Form */}
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            await signIn("credentials", {
              email: formData.get("email"),
              password: formData.get("password"),
              callbackUrl: "/",
            });
          }}
          className="flex flex-col space-y-4"
        >
          <input
            name="email"
            type="email"
            placeholder="Email"
            required
            className="w-full border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            name="password"
            type="password"
            placeholder="Password"
            required
            className="w-full border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button className="bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
            Sign In
          </button>
        </form>

        {/* Google Sign In */}
        <button
          onClick={() => signIn("google", { callbackUrl: "/" })}
          className="bg-red-500 text-white py-3 w-full rounded-lg font-semibold hover:bg-red-600 transition-colors"
        >
          Sign in with Google
        </button>

        {/* Sign Up Option */}
        <p className="text-center text-gray-600">
          Don’t have an account?{" "}
          <Link href="/auth/signup" className="text-blue-600 font-semibold hover:underline">
            Sign Up
          </Link>
        </p>
      </div>
    </main>
  );
}
