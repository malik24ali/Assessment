import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "../auth/[...nextauth]/route";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  const books = await prisma.book.findMany({
    where: { userId: user?.id },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(books);
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  const { title, author, genre } = await req.json();
  if (!title || !author || !genre)
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });

  const book = await prisma.book.create({
    data: { title, author, genre, userId: user!.id },
  });

  return NextResponse.json(book);
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  if (!id)
    return NextResponse.json({ error: "Missing book ID" }, { status: 400 });

  await prisma.book.delete({ where: { id } });

  return NextResponse.json({ message: "Book deleted successfully" });
}
